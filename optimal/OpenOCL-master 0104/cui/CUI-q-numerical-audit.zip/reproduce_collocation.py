"""按所审查 OpenOCL 源码重建同一 Radau 配点问题；不是 MATLAB 运行结果。"""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import casadi as ca
from scipy.integrate import solve_ivp

P,C,GAMMA,K,S0,I0=.5,2.,.3,.15,.99,.01
H=GAMMA/(P*C)
TAU1=4.3491915577
TB=1.5203108877
TQ=0.7138664706

def reference(t):
    t=np.asarray(t).reshape(-1)
    out=np.zeros((3,len(t)))
    r=(1-P)*H
    f=lambda _,x:np.array([-P*C*x[0]*x[1],(P*C*x[0]-GAMMA)*x[1]])
    phase0=solve_ivp(f,[0,TAU1],[S0,I0],method='DOP853',rtol=1e-12,atol=1e-14,dense_output=True)
    end=TAU1+TB+TQ
    phase3=solve_ivp(f,[0,max(float(t.max())-end,1e-6)],[.4516637907,.1210828901],method='DOP853',rtol=1e-12,atol=1e-14,dense_output=True)
    z=t<=TAU1;out[:2,z]=phase0.sol(t[z])
    z=(t>TAU1)&(t<=TAU1+TB)
    out[0,z]=r+(.7775221610-r)*np.exp(-C*K*(t[z]-TAU1))
    out[1,z]=K;out[2,z]=1-H/out[0,z]
    z=(t>TAU1+TB)&(t<=end)
    out[1,z]=K*np.exp(-GAMMA*(t[z]-TAU1-TB))
    out[0,z]=.5476951355*np.exp(-C/GAMMA*(K-out[1,z]));out[2,z]=1
    z=t>end;out[:2,z]=phase3.sol(t[z]-end)
    return out

def replay(q,T):
    n=len(q);dt=T/n
    qphys=np.clip(q,0,1)
    logstate=np.array([S0,np.log(I0)])
    grid=np.empty((2,n+1));grid[:,0]=[S0,I0]
    peak=I0;tpeak=0.;speak=S0
    for k,control in enumerate(qphys):
        def f(_,x):
            return [-C*(P+(1-P)*control)*x[0]*np.exp(x[1]),P*C*(1-control)*x[0]-GAMMA]
        if control<1:
            threshold=H/(1-control)
            def event(_,x):return x[0]-threshold
            event.direction=-1
        else:event=None
        sol=solve_ivp(f,[0,dt],logstate,method='DOP853',rtol=2e-11,atol=2e-13,
                      dense_output=True,events=event)
        ts=np.array([0,dt])
        if event is not None and len(sol.t_events[0]):ts=np.r_[ts,sol.t_events[0]]
        vals=sol.sol(ts);ii=np.exp(vals[1]);idx=np.argmax(ii)
        if ii[idx]>peak:peak=float(ii[idx]);tpeak=k*dt+float(ts[idx]);speak=float(vals[0,idx])
        logstate=sol.y[:,-1];grid[:,k+1]=[logstate[0],np.exp(logstate[1])]
    return dict(peak=peak,peak_time=tpeak,peak_s=speak,grid=grid,
                cost=float(P*C*dt*qphys.sum()),q_min=float(q.min()),q_max=float(q.max()))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--N',type=int,default=4000)
    ap.add_argument('--T',type=float,default=300)
    ap.add_argument('--guess',choices=['source','constant','consistent'],default='source')
    ap.add_argument('--tight',action='store_true')
    ap.add_argument('--terminal-safe',action='store_true')
    ap.add_argument('--outdir',default='results')
    args=ap.parse_args();n,T=args.N,args.T;dt=T/n
    started=time.time()
    X=ca.SX.sym('X',2,n+1);Z1=ca.SX.sym('Z1',2,n);Z2=ca.SX.sym('Z2',2,n);U=ca.SX.sym('U',1,n)
    f=lambda x,u:ca.vertcat(-C*(P+(1-P)*u)*x[0,:]*x[1,:],(P*C*(1-u)*x[0,:]-GAMMA)*x[1,:])
    e1=dt*f(Z1,U)-(-2*X[:,:-1]+1.5*Z1+.5*Z2)
    e2=dt*f(Z2,U)-(2*X[:,:-1]-4.5*Z1+2.5*Z2)
    eq=ca.vertcat(ca.vec(e1),ca.vec(e2),ca.vec(Z2-X[:,1:]))
    var=ca.vertcat(ca.vec(X),ca.vec(Z1),ca.vec(Z2),ca.vec(U))
    objective=P*C*dt*ca.sum2(U)
    lower=np.zeros(var.numel());upper=np.r_[np.tile([1,K],n+1),np.tile([1,K],n),np.tile([1,K],n),np.ones(n)]
    lower[:2]=upper[:2]=[S0,I0]
    if args.terminal_safe:upper[2*n]=H
    nodes=np.linspace(0,T,n+1)
    if args.guess=='constant':
        # 仅使用 q=0.5 的前向积分，不使用任何解析最优切换量。
        def half_control(_,state):
            return [-C*(P+(1-P)*.5)*state[0]*state[1],(P*C*.5*state[0]-GAMMA)*state[1]]
        half=solve_ivp(half_control,[0,T],[S0,I0],method='DOP853',rtol=1e-12,atol=1e-14,dense_output=True)
        xguess=half.sol(nodes);z1guess=half.sol(nodes[:-1]+dt/3);z2guess=half.sol(nodes[1:]);uguess=np.full(n,.5)
    else:
        xguess=reference(nodes)[:2]
        uguess=reference(np.linspace(0,T,n))[2]
        if args.guess=='source':
            # 原脚本修改网格状态，但配点状态仍为默认的初值至零线性插值。
            z1guess=np.array([[S0],[I0]])*(1-np.arange(n)/n)[None,:]
            z2guess=z1guess.copy()
        else:
            z1guess=reference(nodes[:-1]+dt/3)[:2]
            z2guess=reference(nodes[1:])[:2]
            uguess=reference(nodes[:-1])[2]
    initial=np.r_[xguess.flatten(order='F'),z1guess.flatten(order='F'),z2guess.flatten(order='F'),uguess]
    opt={'ipopt.max_iter':10000,'ipopt.linear_solver':'mumps','ipopt.hessian_approximation':'exact',
         'ipopt.print_level':5,'ipopt.max_cpu_time':150,'print_time':False}
    if args.tight:opt.update({'ipopt.tol':1e-10,'ipopt.constr_viol_tol':1e-10,'ipopt.bound_relax_factor':0})
    print(json.dumps({'event':'build','N':n,'T':T,'guess':args.guess,'casadi':ca.__version__}),flush=True)
    solver=ca.nlpsol('solver','ipopt',{'x':var,'f':objective,'g':eq},opt)
    result=solver(x0=initial,lbx=lower,ubx=upper,lbg=0,ubg=0)
    stats=solver.stats();w=np.asarray(result['x']).ravel();off=2*(n+1)
    xv=w[:off].reshape(2,n+1,order='F');z1=w[off:off+2*n].reshape(2,n,order='F');off+=2*n
    z2=w[off:off+2*n].reshape(2,n,order='F');q=w[off+2*n:]
    # 配点二次多项式的内部极值，可直接检查配点之间的过冲。
    aa=3*xv[1,:-1]-4.5*z1[1]+1.5*z2[1]
    bb=-4*xv[1,:-1]+4.5*z1[1]-.5*z2[1]
    with np.errstate(divide='ignore',invalid='ignore'):ext=-bb/(2*aa)
    valid=(aa<0)&(ext>0)&(ext<1)
    candidates=(aa[valid]*ext[valid]+bb[valid])*ext[valid]+xv[1,:-1][valid]
    polymax=max(float(xv[1].max()),float(z1[1].max()),float(z2[1].max()),float(candidates.max()) if len(candidates) else 0)
    roll=replay(q,T)
    sT,iT=roll['grid'][:,-1]
    safe_peak=iT if sT<=H else iT+sT-H+H*np.log(H/sT)
    output={'N':n,'T':T,'dt':dt,'guess':args.guess,'tight':args.tight,'terminal_safe':args.terminal_safe,'casadi':ca.__version__,
            'success':bool(stats['success']),'return_status':stats['return_status'],'iter_count':int(stats['iter_count']),
            'objective_solver':float(result['f']),'objective_rectangle':float(P*C*dt*q.sum()),
            'objective_trapz':float(P*C*np.trapz(q,nodes[:-1])),
            'grid_max_I':float(xv[1].max()),'collocation_max_I':float(max(z1[1].max(),z2[1].max())),
            'polynomial_max_I':polymax,'constraint_max_residual':float(np.abs(np.asarray(result['g'])).max()),
            'replay_max_I':roll['peak'],'replay_peak_time':roll['peak_time'],'replay_max_capacity_excess':roll['peak']-K,
            'replay_max_grid_state_difference':float(np.abs(roll['grid']-xv).max()),
            'replay_terminal_S':float(sT),'replay_terminal_I':float(iT),'replay_natural_future_peak':float(safe_peak),
            'q_min':roll['q_min'],'q_max':roll['q_max'],'cost_clipped_control':roll['cost'],
            'analytic_cost':1.5295111601514733,
            'relative_cost_error_percent':100*(float(result['f'])-1.5295111601514733)/1.5295111601514733,
            'seconds':time.time()-started}
    folder=Path(args.outdir);folder.mkdir(parents=True,exist_ok=True)
    name=f'run_N{n}_T{T:g}_{args.guess}'+('_tight' if args.tight else '')+('_safe' if args.terminal_safe else '')
    (folder/(name+'.json')).write_text(json.dumps(output,indent=2,ensure_ascii=False))
    np.savez_compressed(folder/(name+'.npz'),times=nodes,X=xv,Z1=z1,Z2=z2,q=q,replay=roll['grid'])
    print('AUDIT_RESULT '+json.dumps(output,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
