# 感染阈值约束下追踪隔离的全域最优控制

2026 年 11 月 18 日投稿稿件，第二版。主文与补充材料分别为 [主文 PDF](latex/main.pdf) 和 [补充材料 PDF](latex/supplementary.pdf)。两份文稿的 LaTeX 源码、参考文献和表格宏在同一目录。保留解压后的目录结构，从本文件所在目录运行下列命令。

## 编译

Windows 运行 `.\build.bat`，Linux 或 macOS 运行 `bash build.sh`。需要 XeLaTeX、BibTeX、ctex 及中文字体。主文和补充材料分别输出到 `latex/main.pdf` 和 `latex/supplementary.pdf`。

## 核对表 4 和重绘图 5

```sh
python -m pip install -r requirements.txt
python scripts/verify_analytic_results.py --output reproduction/table4.json
python reproducibility/scaling/figure_followup.py --reproduce-dir reproduction/figure5
```

表 4 的成本、追踪实施时长和新增隔离的易感者比例（占总人口）共用各情景的初值和自然容量入口。核对脚本读取稿件列值与排版精度，逐项比较两种策略。随稿生成的同一份计算结果见 [解析复核记录](data/analytic_verification.json)。

图 5 的[正式作图数据](reproducibility/scaling/figure_data.json)与[绘图脚本](reproducibility/scaling/figure_followup.py)位于同一目录。脚本从解析方程重建五组参数、共 620 点的容量网格，域内 619 点用于作图。面板 (d) 绘制从同一切换点出发的两条尾段的时长差乘以 βγ，即 βγ(T₊,fill − T₊*)，横虚线为 1。程序比对四个面板的完整数据，将再生 PDF、PNG、曲线 JSON 和版面检查写入 `reproduction/figure5/`。`reproducibility/scaling/scan.csv` 保存逐点解析扫描，包括绝对时长差 `Delta_T`。

## 数值轨道和补充表

图 2–4 所用的五个主例保存在 `data/numerical_scenarios/E1.mat` 至 `E5.mat`，选取记录在同目录的 `selection_manifest.json`。使用 MATLAB 在解压根目录运行 `addpath(fullfile(pwd,'matlab','numerical_scenarios')); make_numerical_figures('waiting')` 可用保存的主例重绘带三个事件标记的图 3。E2、E4 的容量退出区间见补充材料 S2。`python scripts/build_grid_error_table.py` 从保存的摘要重建补充表 S3 的 15 行网格误差结果。各组求解的汇总数据位于 `data/numerical_scenarios/revision_checks/`。

`PACKAGE_PROVENANCE.json` 记录每份文件在项目中的来源或生成命令。`MANIFEST.sha256` 给出其余全部文件的 SHA-256 校验值。
