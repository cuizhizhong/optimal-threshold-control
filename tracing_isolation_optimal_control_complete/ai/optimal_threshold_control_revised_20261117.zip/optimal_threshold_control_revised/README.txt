感染阈值约束下追踪隔离的全域最优控制
中文论文阅读性修订版（v2，2026-11-17）

一、先看哪些文件

latex/main.pdf                     修订后的论文主文（含完整证明附录）
latex/supplementary.pdf            独立补充材料：主结果精度、完整网格误差与接受判据
latex/main.tex                    主文 LaTeX 源码
latex/supplementary.tex           补充材料源码
latex/references.bib              参考文献（新增 Pollinger 2023）
latex/generated/                  原有数值宏及误差表生成结果（详细误差仅在补充材料呈现）
figures/                          两份论文编译所需图件及原有 PNG 副本
REVISION_NOTES_zh.txt             对照修改意见的说明、核查结果和适用边界
review/main_changes.diff          相对于所给 GitHub 版本的主文差异
review/supplementary_changes.diff 补充材料差异
review/previous_to_current_main.diff  相对于上一轮44页稿的本次修改
review/supplied_review_zh.txt      第一轮所依据的评审意见

论文的参考版本固定为：
https://github.com/cuizhizhong/optimal-threshold-control
分支：codex/numerical-reproducibility-revision
提交：09140ec16983fa98f1103b873fc03706ff7dd627
目录：tracing_isolation_optimal_control_complete

本包沿用原稿的无回流五仓室模型。归一化移出仓室仍记 r，辅助参数仍为 p=(1-beta)h。
作者、单位等信息沿用原稿的空白设置，投稿时请填写。

二、如何编译

使用包含中文 ctex 宏包的 TeX Live 或 MiKTeX，编译引擎选 XeLaTeX。
编译论文不需要 MATLAB、Python 或重新运行数值优化。

Windows：在解压后的目录运行 build.bat。
Linux/macOS：在该目录运行 bash build.sh。

手动编译主文时，先进入 latex 目录，依次运行：
  xelatex -interaction=nonstopmode -halt-on-error main.tex
  bibtex main
  xelatex -interaction=nonstopmode -halt-on-error main.tex
  xelatex -interaction=nonstopmode -halt-on-error main.tex

补充材料只需在 latex 目录运行两次：
  xelatex -interaction=nonstopmode -halt-on-error supplementary.tex

在其他 LaTeX 编辑器中，请将编译工作目录设为 latex，选择 XeLaTeX，
并保留 latex、figures 的相对位置。图件通过相对路径引用，请勿只复制 main.tex。

所需主要宏包包括 ctex、xeCJK、amsmath、amsthm、mathtools、graphicx、
booktabs、longtable、tabularx、enumitem、setspace、caption、subcaption、
float、placeins、hyperref、natbib、listings、siunitx、fancyhdr。
中文字体使用 ctex 在当前平台的默认字体设置；跨平台字体不同可能改变分页。

三、随附的数据整理与解析核对

下列命令均可从解压目录运行：

  python scripts/build_grid_error_table.py

从原有的保存摘要重新生成 15 组网格误差 CSV 和两张 LaTeX 表格；主文不再加载详细误差表。
仅需 Python 标准库，不调用优化器，也不重新积分 ODE。
来源文件：data/numerical_scenarios/revision_checks/grid_detailed_summary.csv
          data/numerical_scenarios/revision_checks/grid_summary.json
输出：data/revision_grid_errors.csv、data/revision_grid_error_audit.json，
      latex/generated/grid_error_summary.tex、grid_error_table.tex。
详细摘要与简表的 15 行历史 run_id 均不一致，但使用的数值完全一致；审计文件保留该差异，
未改写原始标识，也未将未识别事件记作零误差。

  python scripts/verify_analytic_results.py

需安装 mpmath。脚本以 110 位精度独立二分求根与数值求积，核对端点几何、
公共尾段恒等式、小容量首项和物理参数分类，输出 data/analytic_verification.json。
该核查在上一轮修订时实际执行，本轮沿用保存结果；它不是 MATLAB/OpenOCL 优化实验，
也不以有限样本检验替代论文中的数学证明。

reproducibility/scaling/ 保存原项目的高精度量级扫描脚本及其已保存数据。
运行 analytic_scan.py 需要 mpmath、numpy、matplotlib，并在该子目录生成扫描结果。
symbolic_small_capacity.py 另需 sympy。现有论文图件和原数值宏已保留，
无需运行这些脚本即可编译。

四、MATLAB/OpenOCL 代码与保存运行

matlab/numerical_scenarios/ 保留原项目的求解、评估、事件识别与图表导出代码。
validation/numerical_scenarios/ 包含配置输入及解析检查点。
data/numerical_scenarios/ 保留五个已选主结果、其来源清单，以及主文和新增网格表
对应的 20 份不可覆盖原始运行及 solver sidecar；其余初猜、时域、识别阈值结果提供摘要。
data/archived_validation/ 保留原项目的执行与判据重评报告。

本包以论文编译、数据追溯和证明复核为目的，没有复制原仓库中数百 MB 的重复请求、
全部历史缓存、历史版面截图与第三方文献全文，也没有捆绑 MATLAB、OpenOCL 或 CasADi。
完整历史实验环境与全部缓存仍可在上述固定提交中取得。

若使用自有 MATLAB 环境重新求解，请先安装对应 OpenOCL/CasADi/IPOPT 依赖，
设置 OPENOCL_ROOT，再将 matlab/numerical_scenarios 加入 MATLAB 路径并运行 revision_preflight。
原程序的缓存包含依赖路径、版本和源码指纹；更换环境后不能预设会命中已有缓存。
原程序目录的 README.md 与 review/ORIGINAL_PROJECT_README.md 是历史说明，
其中“本次”、页数、命令路径和执行次数属于原项目历史批次；本包本轮操作以本说明和
REVISION_NOTES_zh.txt 为准。本轮没有执行新的 MATLAB/OpenOCL 优化求解。

五、核查记录

data/analytic_verification.json    独立高精度解析核对
data/revision_grid_error_audit.json 15 组网格误差来源与提取核查
review/build_verification.json    本版两份 PDF 的编译、引用与版面检查摘要
review/editorial_verification_v2.json  本轮数学简化与内容迁移核查
MANIFEST.sha256                   包内文件的 SHA-256 校验清单

本轮保留八节结构，修正局部数学表述、简化切换曲线证明，并将完整 Green 推导移至附录。
正文的数值部分集中展示控制结构与轨道；主结果误差表、网格比较及终端延拓核查统一放入补充材料。
review/previous_* 保存上一轮的源文件或说明，属于历史对照；当前说明以根目录文件为准。
压缩包包含的 main.pdf 与 supplementary.pdf 均由本包最终 LaTeX 源码重新编译。
