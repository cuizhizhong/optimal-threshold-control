@echo off
setlocal
cd /d "%~dp0latex"
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error main.tex
if errorlevel 1 goto failed
bibtex main
if errorlevel 1 goto failed
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error main.tex
if errorlevel 1 goto failed
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error main.tex
if errorlevel 1 goto failed
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error supplementary.tex
if errorlevel 1 goto failed
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error supplementary.tex
if errorlevel 1 goto failed
echo Build completed: latex\main.pdf and latex\supplementary.pdf
exit /b 0
:failed
echo Build failed. Check the LaTeX log in the latex directory.
exit /b 1
