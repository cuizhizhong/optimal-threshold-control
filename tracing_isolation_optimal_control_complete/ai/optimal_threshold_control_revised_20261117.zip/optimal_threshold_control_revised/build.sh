#!/usr/bin/env bash
# Build the main manuscript and the independent supplement with TeX Live/MiKTeX.
set -euo pipefail
cd "$(dirname "$0")/latex"
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error main.tex
bibtex main
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error main.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error main.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error supplementary.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error supplementary.tex
